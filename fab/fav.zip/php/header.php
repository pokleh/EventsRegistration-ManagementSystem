 <header class="header_area">
            <div class="main_menu">
            	<nav class="navbar navbar-expand-lg navbar-light" style="border-bottom:1px solid #cccccc;">
					<div class="container box_1620">
						<!-- Brand and toggle get grouped for better mobile display -->
						<a class="navbar-brand logo_h" href="index"><img src="img/gallery/fav-logo.png" alt="" style="width:30%;"></a>
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
							<ul class="nav navbar-nav menu_nav ml-auto">
								<li class="nav-item"><a class="nav-link" href="index">Home</a></li> 
								<li class="nav-item"><a class="nav-link" href="about-us">About</a></li> 
								<li class="nav-item"><a class="nav-link" href="services">Services</a></li>
								<li class="nav-item"><a class="nav-link" href="contact-us">Contact Us</a></li>
								<li class="nav-item"><a class="nav-link" href="index#sign-in"><button class="genric-btn danger-border">Sign in</button></a></li>
							

						</div> 
					</div>
            	</nav>
            </div>

        </header>