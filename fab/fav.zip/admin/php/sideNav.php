 <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="verifiedreservation"><i class="fa fa-user fa-fw"></i> Verified Reservation</a>
                        </li>
                       
                        <li>
                            <a href="pendingreservation"><i class="fa fa-user fa-fw"></i> Pending Reservation</a>
                        </li>
                        
                        <li>
                            <a href="canceledreservation"><i class="fa fa-trash-o fa-fw"></i> Canceled Reservation</a>
                        </li>
						
						<li>
                            <a href="usersaccount"><i class="fa fa-users fa-fw"></i> Users Account</a>
                        </li>


                       
                        <li>
                            <a href="reports"><i class="fa fa-files-o fa-fw"></i> Reports </a>
                        </li>
                        
                         
                         <li>
                            <a href="administrators"><i class="fa fa-users fa-fw"></i> Admins</a>
                        </li>
                            
                        
                            <li>
                            <a href="events"><i class="fa fa-list-alt fa-fw"></i>List of Events</a>
                        </li>
                                   
                    </ul>
                </div>