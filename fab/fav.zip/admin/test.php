<?php

include('connection.php');



$stmt = $connection->query("SELECT SUM(monthly) as total FROM ");

?>